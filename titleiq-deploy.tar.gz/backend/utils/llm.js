import axios from 'axios';

/**
 * Generate titles and description using LLM
 * @param {string} transcript - Video transcript
 * @param {object} options - { userApiKey: string, provider: 'groq'|'openai'|'claude', userContext: object }
 * @returns {Promise<{titles: string[], description: string, themes: string[]}>}
 */
export async function generateTitlesAndDescription(transcript, options = {}) {
  const { userApiKey, provider = 'groq', userContext = {} } = options;

  // Extract themes first (simple keyword extraction)
  const themes = extractThemes(transcript);

  // Build the prompt with user context
  const prompt = buildPrompt(transcript, themes, userContext);

  // Call appropriate LLM
  let response;
  if (userApiKey) {
    // Use user-provided API key
    if (provider === 'openai') {
      response = await callOpenAI(prompt, userApiKey);
    } else if (provider === 'claude') {
      response = await callClaude(prompt, userApiKey);
    } else {
      throw new Error(`Unsupported provider: ${provider}`);
    }
  } else {
    // Use free Groq API
    response = await callGroq(prompt);
  }

  return parseResponse(response, themes, userContext);
}

/**
 * Add personalized social links and hashtags to description
 */
function personalizeDescription(description, userContext) {
  if (!userContext.social_links && !userContext.hashtags) {
    return description;
  }

  let personalized = description;

  // Add social links section
  if (userContext.social_links && Object.keys(userContext.social_links).length > 0) {
    personalized += '\n\n🔗 Connect with me:\n';

    if (userContext.social_links.youtube) {
      personalized += `📺 YouTube: ${userContext.social_links.youtube}\n`;
    }
    if (userContext.social_links.instagram) {
      personalized += `📸 Instagram: ${userContext.social_links.instagram}\n`;
    }
    if (userContext.social_links.tiktok) {
      personalized += `🎵 TikTok: ${userContext.social_links.tiktok}\n`;
    }
    if (userContext.social_links.twitter) {
      personalized += `🐦 Twitter: ${userContext.social_links.twitter}\n`;
    }
    if (userContext.social_links.linkedin) {
      personalized += `💼 LinkedIn: ${userContext.social_links.linkedin}\n`;
    }
    if (userContext.social_links.facebook) {
      personalized += `👥 Facebook: ${userContext.social_links.facebook}\n`;
    }
  }

  // Add hashtags
  if (userContext.hashtags && userContext.hashtags.length > 0) {
    personalized += '\n' + userContext.hashtags.map(tag => tag.startsWith('#') ? tag : '#' + tag).join(' ');
  }

  // Add CTA based on primary goal
  if (userContext.primary_goal) {
    personalized += '\n\n';
    if (userContext.primary_goal.toLowerCase().includes('growth')) {
      personalized += `🚀 Subscribe for more ${userContext.niche || 'content'}!`;
    } else if (userContext.primary_goal.toLowerCase().includes('engagement')) {
      personalized += `💬 Drop a comment and let me know what you think!`;
    } else if (userContext.primary_goal.toLowerCase().includes('monetization')) {
      personalized += `👍 Like and subscribe to support the channel!`;
    } else {
      personalized += `🔔 Hit subscribe and turn on notifications!`;
    }
  }

  return personalized;
}

/**
 * Extract core themes and recurring phrases
 */
function extractThemes(transcript) {
  const words = transcript.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/);

  // Count word frequency
  const frequency = {};
  words.forEach(word => {
    if (word.length > 4) { // Filter out short words
      frequency[word] = (frequency[word] || 0) + 1;
    }
  });

  // Get top 10 most frequent words
  const themes = Object.entries(frequency)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([word]) => word);

  return themes;
}

/**
 * Build the LLM prompt for title generation with 2026 viral factors
 */
function buildPrompt(transcript, themes, userContext = {}) {
  const contextInfo = userContext.niche ? `\nCREATOR NICHE: ${userContext.niche}` : '';
  const competitorInfo = userContext.competitors ? `\nCOMPETITORS TO STUDY: ${userContext.competitors.join(', ')}` : '';
  const brandVoice = userContext.brand_voice ? `\nBRAND VOICE: ${userContext.brand_voice}` : '';
  const targetKeywords = userContext.keywords ? `\nTARGET KEYWORDS: ${userContext.keywords.join(', ')}` : '';

  return `You are an elite YouTube title strategist using 2026 viral optimization techniques. Your titles achieve 15%+ CTR (top 1% performance).

TRANSCRIPT:
${transcript.substring(0, 3000)} ${transcript.length > 3000 ? '...(truncated)' : ''}

CORE THEMES:
${themes.join(', ')}${contextInfo}${competitorInfo}${brandVoice}${targetKeywords}

2026 VIRAL FACTORS (CRITICAL):
1. 4%+ CTR in first 24 hours = 3x more impressions
2. 7%+ CTR = cross-vertical recommendations
3. 15%+ CTR = viral distribution (your target)
4. Optimal length: 40-60 characters (50-60 for algorithm pickup)
5. Front-load primary keywords in first 40 characters (mobile truncation)
6. Brackets increase CTR by 38% when used appropriately
7. Algorithm now penalizes misleading titles through AI content analysis
8. High-arousal emotions (awe, anger, anxiety) drive 267% more shares
9. Odd numbers (3, 5, 7) outperform even numbers
10. Specific timeframes ("30 days") outperform vague ("quickly")

POWER WORDS FOR 2026:
- Curiosity: Secret, Hidden, Surprising, Revealed, Finally
- Authority: Proven, Research-backed, Expert-approved
- Emotional: Amazing, Shocking, Critical, Game-changing
- Time-sensitive: Now, Today, Breaking, Before it's too late

REQUIREMENTS:
1. Generate exactly 10 titles
2. **CONTRAST RULE**: At least 4 titles MUST use aggressive contrast (logical OR illogical).
   - Logical contrast: "I Spent $10,000 To Prove Why $0 Is Smarter"
   - Illogical contrast: "I Failed Miserably And Won Completely"
   - Must create tension and curiosity, not just "A vs B"
3. **CURIOSITY RULE**: ALL 10 titles must weaponize curiosity. Viewer must think: "I don't understand this but I NEED to."
4. **LENGTH RULE**: At least 4 titles must be long-form hooks (up to ~100 characters). Rest can be tight punches.
5. Front-load power words in first 40 characters (mobile optimization)
6. Use psychological triggers: curiosity gaps, fear/urgency, authority, status elevation
7. Include status-flex language where appropriate ("they don't want you to know," "elite unlock," "superiority")
8. Ensure titles accurately represent content

PROVEN VIRAL TITLE PATTERNS (use these):
1. Experience Documentation: "I [Action] for [Time Period] and [Unexpected Result]"
2. Curiosity Gap + Authority: "[Authoritative Figure] Don't Want You to Know This" (23% higher engagement)
3. Question-Based Cliff-Hanger: "What Happens When [Unexpected Scenario]?"
4. Transformation/Before-After: "How I [Achieved Result] in [Specific Timeframe]"
5. Four-Element Formula: Urgency + Value + Uniqueness + Authority

CLASSIC FORMULAS (mix with patterns above):
- Shock + Keyword + Outcome
- Status Game Flip
- Villain/Expose + Contrast
- Quest/Constraint + Illogical Element
- Make/Break Decision
- Identity Hook + Obstacle Removal
- Contrarian How-To + Status Elevation

ALSO GENERATE:

**DESCRIPTION (500-800 characters):**
- 2X longer than typical YouTube description
- SEO-optimized for 2026 discoverability with target keywords${targetKeywords ? ' including: ' + userContext.keywords.join(', ') : ''}
- High-intent keywords relevant to transcript topic
- Match brand voice:${brandVoice ? ' ' + userContext.brand_voice : ' authentic and engaging'}
- Natural call to action aligned with creator goal${userContext.primary_goal ? ' (' + userContext.primary_goal + ')' : ''}
- Include one self-reference: "Optimized with TitleIQ by TightSlice"${userContext.social_links ? '\n- END with social media section (provided separately in user context)' : ''}

**TAGS (comma-separated, <500 chars total):**
- Mix of broad, niche, and long-tail keywords
- Aligned with transcript topic
- Formatted as: tag1, tag2, tag3, etc.

FORMAT YOUR RESPONSE EXACTLY AS:
TITLES:
1. [Title 1]
2. [Title 2]
3. [Title 3]
4. [Title 4]
5. [Title 5]
6. [Title 6]
7. [Title 7]
8. [Title 8]
9. [Title 9]
10. [Title 10]

DESCRIPTION:
[Your 500-800 character SEO-optimized description with TitleIQ mention]

TAGS:
[tag1, tag2, tag3, etc.]`;
}

/**
 * Parse LLM response into structured data
 */
function parseResponse(response, themes, userContext = {}) {
  const lines = response.split('\n').filter(line => line.trim());

  const titles = [];
  let description = '';
  let tags = '';
  let inDescriptionSection = false;
  let inTagsSection = false;

  for (const line of lines) {
    // Extract numbered titles
    const titleMatch = line.match(/^\d+\.\s*(.+)$/);
    if (titleMatch && titles.length < 10) {
      titles.push(titleMatch[1].trim());
      continue;
    }

    // Start collecting description
    if (line.includes('DESCRIPTION:')) {
      inDescriptionSection = true;
      inTagsSection = false;
      continue;
    }

    // Start collecting tags
    if (line.includes('TAGS:')) {
      inTagsSection = true;
      inDescriptionSection = false;
      continue;
    }

    if (inDescriptionSection && !inTagsSection) {
      description += line.trim() + ' ';
    }

    if (inTagsSection) {
      tags += line.trim() + ' ';
    }
  }

  // Ensure we have exactly 10 titles
  if (titles.length < 10) {
    throw new Error(`Only generated ${titles.length} titles, expected 10`);
  }

  // Trim and limit
  description = description.trim().substring(0, 800);
  tags = tags.trim().substring(0, 500);

  // Personalize description with user's social links and hashtags
  const personalizedDescription = personalizeDescription(description, userContext);

  return {
    titles: titles.slice(0, 10),
    description: personalizedDescription,
    tags,
    themes
  };
}

/**
 * Call Groq free API (Llama 3)
 */
async function callGroq(prompt) {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    throw new Error('GROQ_API_KEY not configured. Please add to .env file.');
  }

  const response = await axios.post(
    'https://api.groq.com/openai/v1/chat/completions',
    {
      model: 'llama-3.3-70b-versatile',
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.8,
      max_tokens: 2000
    },
    {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    }
  );

  return response.data.choices[0].message.content;
}

/**
 * Call OpenAI API (user-provided key)
 */
async function callOpenAI(prompt, apiKey) {
  const response = await axios.post(
    'https://api.openai.com/v1/chat/completions',
    {
      model: 'gpt-4',
      messages: [
        { role: 'user', content: prompt }
      ],
      temperature: 0.8,
      max_tokens: 2000
    },
    {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json'
      }
    }
  );

  return response.data.choices[0].message.content;
}

/**
 * Call Claude API (user-provided key)
 */
async function callClaude(prompt, apiKey) {
  const response = await axios.post(
    'https://api.anthropic.com/v1/messages',
    {
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 2000,
      messages: [
        { role: 'user', content: prompt }
      ]
    },
    {
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'Content-Type': 'application/json'
      }
    }
  );

  return response.data.content[0].text;
}
